Linear regression:
input1.csv is train set
public_test1.csv is test data
public_solution1.txt is output


Logistic regression:
input2.csv is train set
public_test2.csv is test data
public_solution2.txt is output Lables
