#Code for Part1
#   Standard Naive bayes code