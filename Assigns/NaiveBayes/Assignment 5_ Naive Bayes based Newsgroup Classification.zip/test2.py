#Code for Part2
#   Improved Naive bayes code